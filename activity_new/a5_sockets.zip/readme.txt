READ ME

card special values:
K = 10
Q = 10
J = 10
A = 11/1
0 = 10

